package com.rachmad.app.league.data

data class ErrorData(
    val status_code: Int,
    val status_message: String?
)